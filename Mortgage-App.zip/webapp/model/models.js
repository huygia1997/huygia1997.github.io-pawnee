sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";
	var serverInfo = {
		url: "http://192.168.2.60:8080",
		localUrl: "model",
		useLocal: true
	};
	return {
		getServerInfo: function() {
			return serverInfo;
		},
		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createNotiModel: function() {
			var model = new JSONModel([]);
			// setInterval(this.getNoti, 100000, ms);
			return model;
		},
		checkLogin: function(username, password) {
			var data = [];
			var ajaxData = {
				username: username,
				password: password
			};
			var url;
			if (serverInfo.useLocal) {
				url = serverInfo.localUrl + "/account.json";
			} else {
				url = serverInfo.url + "/dang-nhap";
			}
			$.ajax({
				type: "GET",
				url: url,
				context: this,
				dataType: 'json',
				data: ajaxData,
				async: false,
				success: function(d, r, xhr) {
					data = d;
				},
				error: function(e) {

				}

			});
			return data;
		},

		getBestShop: function() {
			var data = [];
			var url;
			if (serverInfo.useLocal) {
				url = serverInfo.localUrl + "/shop.json";
			} else {
				url = serverInfo.url + "/dang-nhap";
			}
			$.ajax({
				type: "GET",
				url: url,
				context: this,
				dataType: 'json',
				async: false,
				success: function(d, r, xhr) {
					data = d;
				},
				error: function(e) {
					
				}

			});
			return data;
		}

	};

});