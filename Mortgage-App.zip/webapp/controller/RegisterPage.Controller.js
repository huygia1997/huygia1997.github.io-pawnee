sap.ui.define([
	'Mortgage-App/controller/BaseController',
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("Mortgage-App.controller.RegisterPage", {
		onInit: function(){
			
		},
		openLoginPage: function() {
			this.getRouter().navTo("loginPage");
		}
	});

});