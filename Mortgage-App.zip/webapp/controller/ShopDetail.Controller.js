sap.ui.define([
	'Mortgage-App/controller/BaseController',
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	var gMap;
	return BaseController.extend("Mortgage-App.controller.ShopDetail", {
		onInit: function() {
			var oRouter = this.getRouter();

			this.getView().byId("map").addStyleClass("myMap");
			oRouter.getRoute("shopDetail").attachPatternMatched(this._onRouteMatched, this);

		},

		_onRouteMatched: function(oEvent) {
			var that = this;
			var shopId = oEvent.getParameter("arguments").shopId;
			var userId = this.getGlobalModel().getProperty("/accountId");
			if (userId !== "") {
				var onSuccess = function(res, status, xhr) {
					that.getDataShop(res);
					that.getCateItem(res);
				};
				var onError = function(jqXHR, textStatus, errorThrown) {};
				$.ajax({
					type: "GET",
					// crossDomain: true,
					// data: {
					// 	shopId: shopId,
					// 	userId: userId
					// },
					// url: "http://172.20.10.2:8080/khach/thong-tin-cua-hang",
					url: "model/shopDetail.json",
					dataType: "json",
					success: onSuccess,
					error: onError
				});
			} else {
				var onSuccessGuest = function(res, status, xhr) {
					that.getDataShop(res);
					that.getCateItem(res);
				};
				var onErrorGuest = function(jqXHR, textStatus, errorThrown) {};
				$.ajax({
					type: "GET",
					// crossDomain: true,
					// data: {
					// 	shopId: shopId
					// },
					// url: "http://172.20.10.2:8080/khach/thong-tin-cua-hang",
					url: "model/shopDetail.json",
					dataType: "json",
					success: onSuccessGuest,
					error: onErrorGuest
				});
			}
		},

		getDataShop: function(res) {
			var lat = res.latitude,
				lng = res.longtitude;
			var dataShopDetail = new JSONModel({
				shopName: res.shopName,
				phoneNumber: res.phoneNumber,
				fullAddress: res.fullAddress,
				facebook: res.facebook,
				viewCount: res.viewCount,
				avaUrl: res.avaUrl,
				rating: res.rating,
				lat: res.latitude,
				lng: res.longtitude,
				policy: res.policy
			});
			this.setModel(dataShopDetail, "dataShopDetail");

			this.setLocationShop(lat, lng);
		},

		getCateItem: function(res) {
			var cateItem = new JSONModel();
			cateItem.setData({
				results: res.categoryItems
			});
			this.setModel(cateItem, "cateItem");
		},

		setLocationShop: function(lat, lng) {
			var latLong = new google.maps.LatLng(lat, lng);
			if (!this.marker) {
				this.marker = new google.maps.Marker({
					position: latLong,
					map: gMap
				});
				this.marker.setMap(gMap);
			} else {
				this.marker.setPosition(latLong);
			}
			gMap.setZoom(15);
			gMap.setCenter(this.marker.getPosition());
		},

		navToGGMap: function() {
			var lat = this.getModel("dataShopDetail").getData().lat;
			var lng = this.getModel("dataShopDetail").getData().lng;
			var url = "https://www.google.com/maps/dir//" + lat + "," + lng;
			sap.m.URLHelper.redirect(url, true);
		},

		backToPrevious: function() {
			this.back();
		},

		onAfterRendering: function() {
			var mapOptions = {
				center: new google.maps.LatLng(0, 0),
				zoom: 1,
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};
			gMap = new google.maps.Map(this.getView().byId("map").getDomRef(), mapOptions);
		}
	});

});