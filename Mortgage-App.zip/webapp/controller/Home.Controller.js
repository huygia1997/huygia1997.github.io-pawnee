sap.ui.define([
	'Mortgage-App/controller/BaseController',
	"sap/ui/model/json/JSONModel",
	'Mortgage-App/model/models'
], function(BaseController, JSONModel, models) {
	"use strict";

	return BaseController.extend("Mortgage-App.controller.Home", {
		onInit: function() {
			this.getBestShop();
			this.openLocationSystem();
			var userId = this.getGlobalModel().getProperty("/accountId");
			this.getCountNoti(userId);
		},

		getBestShop: function() {
			// var that = this;
			// var onSuccess = function(res, status, xhr) {
			// 	var oModelShop = new JSONModel();
			// 	// that.renderCarousel(res);
			// 	oModelShop.setData({
			// 		results: res
			// 	});
			// 	that.setModel(oModelShop, "oModelShop");
			// 	console.log(oModelShop);
			// };
			// var onError = function(jqXHR, textStatus, errorThrown) {};
			// $.ajax({
			// 	type: "GET",
			// 	url: "model/shop.json",
			// 	dataType: "json",
			// 	success: onSuccess,
			// 	error: onError
			// });
			var getData = models.getBestShop();
			if(getData) {
				var oModelShop = new JSONModel();
				// this.renderCarousel(getData);
				oModelShop.setData({
					results: getData
				});
				this.setModel(oModelShop, "oModelShop");
			}
		},
		renderCarousel: function(res) {
			var carousel = this.byId("__carousel0");
			for (var r in res) {
				var header = new sap.m.ObjectHeader({
					title: r.shopName
				});
				carousel.addPage(header);
			}
		},
		
		navToSearchFilterShop: function() {
			this.getRouter().navTo("searchFilterShop");
		},
		
		navToShopDetail: function(oEvent) {
			var item = oEvent.getSource();
			var bindingContext = item.getBindingContext("oModelShop");
			if(bindingContext) {
				var shopId = bindingContext.getProperty("id");
				this.getRouter().navTo("shopDetail", {
					shopId: shopId
				}, false);
			}
		},
		
		openLocationSystem: function() {
			var that = this;
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(function(position) {
					var lat = position.coords.latitude,
						lng = position.coords.longitude;
					that.getGlobalModel().setProperty("/lat", lat);
					that.getGlobalModel().setProperty("/lng", lng);
				}, function() {
					MessageBox.error("Bạn từ chối chia sẻ vị trí. Hãy bật nó lên để sử dụng chức năng này hoặc sử dụng các công cụ tìm kiếm khác.");
				});
			} else {
				// Browser doesn't support Geolocation
				MessageBox.error("Trình duyệt của bạn không hỗ trợ Geolocation");
			}
		}
	});

});