sap.ui.define([
	'Mortgage-App/controller/BaseController',
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("Mortgage-App.controller.SearchFilterShop", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Mortgage-App.view.SearchFilterShop
		 */
		onInit: function() {

			var oModel = new sap.ui.model.json.JSONModel();
			this.setModel(oModel, "dataCity");

			var oModelShop = new JSONModel();
			this.setModel(oModelShop, "oModelShop");

			var keyOfDialog = new sap.ui.model.json.JSONModel({
				"keyDis": "",
				"keyCate": "",
				"isFiltering": false
			});
			this.setModel(keyOfDialog, "keyOfDialog");
			this.getBestShop();
		},

		_onRouteMatched: function() {

		},

		getDataCategory: function() {
			var that = this;
			var onSuccess = function(res, status, xhr) {
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					results: res
				});
				that.setModel(oModel, "dataCate");

			};
			var onError = function(jqXHR, textStatus, errorThrown) {};
			$.ajax({
				type: "GET",
				url: "model/category.json",
				dataType: "json",
				success: onSuccess,
				error: onError
			});
		},

		getDataCity: function() {
			var that = this;
			var onSuccessOfCity = function(res, status, xhr) {
				var oModel = that.getModel("dataCity");

				oModel.setProperty("/results", res);
				oModel.setProperty("/selectedCity", res[0].id);
				oModel.updateBindings();

			};
			var onErrorOfCity = function(jqXHR, textStatus, errorThrown) {};
			$.ajax({
				type: "GET",
				url: "model/dataLocation.json",
				dataType: "json",
				success: onSuccessOfCity,
				error: onErrorOfCity
			});

			/***************************************************/
			/** Get data Distrisct **/
			var onSuccessOfDistrisct = function(res, status, xhr) {
				var dataDis = [];
				for (var i = 0; i < res.length; i++) {
					// console.log(res[i].districctName);
					// if (keyCity == res[i].cityId) {
					// console.log(res[i].districtName);
					dataDis.push(res[i]);
					// }
				}

				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData({
					results: dataDis
				});
				that.setModel(oModel, "dataDis");
				that.onChangeCity();
			};
			var onErrorOfDistrisct = function(jqXHR, textStatus, errorThrown) {};
			$.ajax({
				type: "GET",
				url: "model/dataDistrisct.json",
				dataType: "json",
				success: onSuccessOfDistrisct,
				error: onErrorOfDistrisct
			});
			/***************************************************/
		},

		getDistrictByCity: function(cityId) {
			var filters = [];
			var cityIdFilter = new sap.ui.model.Filter({
				path: "cityId",
				operator: "EQ",
				value1: cityId
			});
			filters.push(cityIdFilter);
			this.byId("filterDistrict").getBinding("items").filter(filters);
		},

		onChangeCity: function() {
			var cityModel = this.getModel("dataCity");
			if (cityModel) {
				// var cityContext = this.getView().byId("filterCity").getSelectedItem().getKey();
				var keyCity = cityModel.getProperty("/selectedCity");
				this.getDistrictByCity(keyCity);
			}
		},

		backToPreviousPage: function() {
			this.back();
		},

		getBestShop: function() {
			this.getModel("oModelShop").setData(null);
			this.getModel("oModelShop").updateBindings();
			// check was filter
			var checkFilter = this.getModel("keyOfDialog").getProperty("/isFiltering");

			var that = this;
			if (checkFilter === false) {
				var onSuccess = function(res, status, xhr) {
					var oModelShop = that.getModel("oModelShop");
					oModelShop.setData({
						results: res
					});
				};
				var onError = function(jqXHR, textStatus, errorThrown) {};
				$.ajax({
					type: "GET",
					url: "model/shop.json",
					dataType: "json",
					success: onSuccess,
					error: onError
				});
			} else {
				var keyModel = this.getModel("keyOfDialog");

				var onSuccessKeyFilter = function(res, status, xhr) {
					var oModelShop = that.getModel("oModelShop");
					oModelShop.setData({
						results: res
					});
					console.log(oModelShop);
				};
				var onErrorKeyFilter = function(jqXHR, textStatus, errorThrown) {};
				$.ajax({
					type: "GET",
					url: "model/shopByFilter.json",
					dataType: "json",
					success: onSuccessKeyFilter,
					error: onErrorKeyFilter
				});
			}
		},

		navToNearByLocation: function() {
			var lat = this.getGlobalModel().getProperty("/lat");
			var lng = this.getGlobalModel().getProperty("/lng");
			this.getRouter().navTo("nearByLocation", {
				lat: lat,
				lng: lng
			}, false);
		},

		navToShopDetail: function(oEvent) {
			var item = oEvent.getSource();
			var bindingContext = item.getBindingContext("oModelShop");
			if (bindingContext) {
				var shopId = bindingContext.getProperty("id");
				this.getRouter().navTo("shopDetail", {
					shopId: shopId
				}, false);
			}
		},

		openDialogFilter: function() {
			if (!this._FilterDialog) {
				this._FilterDialog = sap.ui.xmlfragment(this.getId(), "Mortgage-App.fragment.FilterBox",
					this);
				var filterDialogModel = new JSONModel();
				this._FilterDialog.setModel(filterDialogModel, "filterResult");
				//Set models which is belonged to View to Fragment
				this.getView().addDependent(this._FilterDialog);
				/** Get data **/
				this.getDataCity();
				this.getDataCategory();
				/***************************************************/
			}
			this._FilterDialog.open();
		},

		searchPlaceByForm: function() {
			this.getModel("keyOfDialog").setProperty("/isFiltering", true);

			var keyDistrics = this.getView().byId("filterDistrict").getSelectedItem().getKey();
			var keyItem = this.getView().byId("filterItem").getSelectedItem().getKey();

			this.getModel("keyOfDialog").setProperty("/keyDis", keyDistrics);
			this.getModel("keyOfDialog").setProperty("/keyCate", keyItem);

			this.getBestShop();
			this._FilterDialog.close();
		},
		
		onChangeFilter: function() {
			var selectKey = this.getView().byId("filterSort").getSelectedItem().getKey();
			
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Mortgage-App.view.SearchFilterShop
		 */
		onBeforeRendering: function() {

		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Mortgage-App.view.SearchFilterShop
		 */
		onAfterRendering: function() {

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Mortgage-App.view.SearchFilterShop
		 */
		onExit: function() {

		}

	});

});