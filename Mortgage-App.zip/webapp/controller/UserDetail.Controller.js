sap.ui.define([
	'Mortgage-App/controller/BaseController',
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("Mortgage-App.controller.UserDetail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf Mortgage-App.view.Search
		 */
		onInit: function() {
			this.getUserInfo();
			var userId = this.getGlobalModel().getProperty("/accountId");
			this.getCountNoti(userId);
		},

		getUserInfo: function() {
			var that = this;
			var onSuccess = function(res, status, xhr) {
				// console.log(res);
				// get data user information
				var dataUser = new JSONModel({
					name: res.name,
					email: res.email,
					phone: res.phoneNumber,
					address: res.address,
					avatar: res.avaURL
				});
				that.setModel(dataUser, "dataUser");

				// get data notification
				var listNotification = res.listNotification;
				var dataNotify = new JSONModel();
				dataNotify.setData({
					results: listNotification
				});
				that.setModel(dataNotify, "dataNotify");

				// get data transaction
				var listTrans = res.listTransaction;
				var dataTrans = new JSONModel();
				dataTrans.setData({
					results: listTrans
				});
				that.setModel(dataTrans, "dataTrans");
			};
			var onError = function(jqXHR, textStatus, errorThrown) {};
			$.ajax({
				type: "GET",
				// crossDomain: true,
				// url: "http://172.20.10.2:8080/thong-tin-nguoi-dung/" + id,
				url: "model/userDetail.json",
				dataType: "json",
				success: onSuccess,
				error: onError
			});
		},

		logout: function() {
			this.getGlobalModel().setProperty("/accountId", "");
			this.getGlobalModel().setProperty("/username", "");
			this.getGlobalModel().setProperty("/role", "");
			this.getGlobalModel().setProperty("/password", "");
			this.getGlobalModel().setProperty("/lat", "");
			this.getGlobalModel().setProperty("/lng", "");

			// remove localStorage
			localStorage.removeItem("username");
			localStorage.removeItem("token");
			localStorage.removeItem("isLogging");

			var oModelNoti = this.getModel("noti");
			oModelNoti.setProperty("/count", "");
			oModelNoti.updateBindings(true);

			this.getRouter().navTo("home");
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf Mortgage-App.view.Search
		 */
		onBeforeRendering: function() {

		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf Mortgage-App.view.Search
		 */
		onAfterRendering: function() {

		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf Mortgage-App.view.Search
		 */
		onExit: function() {

		}

	});

});