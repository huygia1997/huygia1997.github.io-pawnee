sap.ui.define([
	'Mortgage-App/controller/BaseController',
	'Mortgage-App/model/models',
	"sap/ui/model/json/JSONModel",
	'sap/m/MessageBox'
], function(BaseController, models, JSONModel, MessageBox) {
	"use strict";

	return BaseController.extend("Mortgage-App.controller.LoginPage", {
		onInit: function() {
			var loginModel = new JSONModel({
				username: "",
				password: "",
				failed: false,
				isLogging: false
			});
			this.setModel(loginModel, "loginModel");
		},

		openRegisterPage: function() {
			this.getRouter().navTo("registerPage");
		},

		validateEmail: function() {
			var emailValue = this.getView().byId("userName").getValue();

			var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;

			if (!mailregex.test(emailValue)) {
				this.getView().byId("userName").setValueState(sap.ui.core.ValueState.Error);
			}
		},

		checkToLogin: function() {
			var emailValue = this.getView().byId("userName").getValue();
			var checkEmail = this.validateEmailGlobal(emailValue);
			var loginModel = this.getModel("loginModel");
			var username = loginModel.getProperty("/username");
			var password = loginModel.getProperty("/password");
			// 
			if (username === "" || password === "") {
				this.getView().byId("userName").setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId("passwordUser").setValueState(sap.ui.core.ValueState.Error);
				MessageBox.error("Không được để trống!");
			} else if (!checkEmail) {
				MessageBox.error("Email không đúng định dạng");
			} else {
				// var onSuccess = function(res, status, xhr) {
				// 		if (res.role.roleName === "ROLE_PAWNER") {
				// 			//post-process
				// 			that.getGlobalModel().setProperty("/accountId", res.id);
				// 			that.getGlobalModel().setProperty("/username", res.username);
				// 			that.getGlobalModel().setProperty("/role", res.role);
				// 			that.getGlobalModel().setProperty("/password", res.password);
				// 			that.getGlobalModel().setProperty("/lat", res.lat);
				// 			that.getGlobalModel().setProperty("/lng", res.lng);

				// 			//save_login to LocalStorage
				// 			localStorage.setItem("username", res.username);
				// 			localStorage.setItem("token", res.password);

				// 			that.getRouter().navTo("userDetail");

				// 			setInterval(that.getCountNoti(res.id), 10000);
				// 		}
				// 		localStorage.setItem("isLogging", true);
				// 	},
				// 	onError = function(jqXHR, textStatus, errorThrown) {
				// 		localStorage.setItem("isLogging", false);
				// 	};
				// $.ajax({
				// 	// data: logonData,
				// 	// type: "POST",
				// 	// crossDomain: true,
				// 	// url: "http://192.168.2.66:8080/dang-nhap",
				// 	//local
				// 	url: "model/account.json",
				// 	type: "GET",
				// 	//end-local
				// 	dataType: "json",
				// 	success: onSuccess,
				// 	error: onError
				// });
				var dataLogin = models.checkLogin(username, password);
				if (dataLogin) {
					this.getGlobalModel().setProperty("/accountId", dataLogin.id);
					this.getGlobalModel().setProperty("/username", dataLogin.username);
					this.getGlobalModel().setProperty("/role", dataLogin.role);
					this.getGlobalModel().setProperty("/password", dataLogin.password);
					this.getGlobalModel().setProperty("/lat", dataLogin.lat);
					this.getGlobalModel().setProperty("/lng", dataLogin.lng);

					//save_login to LocalStorage
					localStorage.setItem("username", dataLogin.username);
					localStorage.setItem("token", dataLogin.password);

					this.getRouter().navTo("userDetail");

					setInterval(this.getCountNoti(dataLogin.id), 10000);
					localStorage.setItem("isLogging", true);
				} else {
					localStorage.setItem("isLogging", false);
					MessageBox.error("Đăng nhập thất bại!");
				}
			}
		}
	});

});